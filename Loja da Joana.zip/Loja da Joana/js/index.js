col.innerHTML = `
  <div class="card bg-black text-white h-100 border-secondary d-flex flex-column">
    <img src="${produto.image}" class="card-img-top p-3" style="height: 300px; object-fit: contain;" alt="${produto.title}">
    <div class="card-body flex-grow-1">
      <h5 class="card-title">${produto.title}</h5>
      <p class="card-text">${produto.description.substring(0, 100)}...</p>
    </div>
    <div class="card-footer border-top border-secondary">
      <div class="d-flex justify-content-between align-items-center">
        <strong>R$ ${produto.price.toFixed(2).replace('.', ',')}</strong>
        <button class="btn btn-outline-light btn-sm">Comprar</button>
      </div>
    </div>
  </div>
`;
